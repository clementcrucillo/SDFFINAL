/*
Programmer: Ciara Mae Padillo
Purpose: Hands-on Activity on Control 
Date: 04.09.25
*/

package shoppingcartsystem;

public class Item {
    private String  itemName;
    private double price;
    private int quantity;
    
    public Item(String itemName, double price, int quantity){
        this.itemName = itemName;
        this.price = price;
        this.quantity = quantity;
    }
    
    public void setItemName(String itemName){
        this.itemName =itemName;
    }
    
    public String getItemName(){
        return itemName;
    }
    
    public void setPrice(double price){
        this.price = price;
    }
    
    public double getPrice(){
        return price;
    }
     public void getQuantity(int quantity){
         this.quantity = quantity;
    }
     
    public int getQuantity(){
        return quantity;
    }
    
    public double getsubtotal(){
        return price * quantity;
    }
}
