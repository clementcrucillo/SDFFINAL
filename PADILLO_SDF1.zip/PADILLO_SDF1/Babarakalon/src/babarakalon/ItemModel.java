package babarakalon;

public class ItemModel {
    private String name;
    private double price;
    
    public ItemModel(String name, double price){
        this.name = name;
    }
}
