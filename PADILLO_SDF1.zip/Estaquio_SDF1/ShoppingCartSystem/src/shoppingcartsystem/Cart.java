package shoppingcartsystem;
import java.util.Scanner;
/**
 * Programmer: Allana Mae B. Estaquio
 * Purpose: Hands-on Activity on Control Structures and Encapsulation
 * Date: 04.09.2025
 */
public class Cart {
    item[] Items;
    private double subtotal;
    private int itemCount;
    
    public Cart(int size){
        Items = new Item[size];
        itemCount = 0;
        subtotal = 0;
    }
    
    public void addItem(Item i){
        Items[itemCount] = i;
        itemCount++;
    }
    
    public double computeSubtotal(){
        subtotal = 0;
        for (int j = 0; j < itemCount; j++){
            subtotal += Items[j].getTotalPrice();
        }
        return subtotal;
    }
    
    public double applyDiscount(){
        double discount = 0;
        if(subtotal >= 500){
            discount = subtotal * 0.20;
        }
        else if(subtotal >= 200 && subtotal < 500){
            discount = subtotal * 0.10;
        }
        return discount;
        
    }
    
    public void displayCart(){
        System.out.println("\n--- Shopping Cart Summary ---");
        System.out.printf("");
    }
}
