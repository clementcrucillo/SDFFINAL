package babarakalonprogram;
import java.util.Scanner;

public class ItemView {
    private Scanner sc = new Scanner(System.in);
    
    public int showMenu(){
        System.out.println("Grocery List");
        System.out.println("[A] - Add Item\n[D] - Delete Item\n[I] - Display All Items\n[E] - Exit\n");
        System.out.print("Choose an operation: ");
        
        String option = sc.nextLine();
        
        if(option.equalsIgnoreCase("a")){
            return 1;
        }else if(option.equalsIgnoreCase("d")){
            return 2;
        }else if(option.equalsIgnoreCase("i")){
            return 3;
        }else if(option.equalsIgnoreCase("e")){
            return 0;
        }
    
        System.err.println("Invalid option");
        return -1;
    }
    
    public ItemModel addItemView(){
        System.out.println("");
    }
    
    public String deleteItemView(){
        System.out.println("Delete Item");
    }
    
    public void displayItem(ItemModel item){
        System.out.println( );
    }
    
}
