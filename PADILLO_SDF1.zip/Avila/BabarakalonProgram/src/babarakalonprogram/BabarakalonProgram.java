
package babarakalonprogram;

/**
 *
 * @author bscs_A - Mitch Lei D. Avila
 */
public class BabarakalonProgram {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
