
package babarakalonprogram;

/**
 *
 * @author bscs_A - Mitch Lei D. Avila
 */
public class ItemModel {
    private String name;
    private String price;
    
    public ItemModel(){
        this.name = "";
        this.price = "";
    }
    
    public ItemModel(String name, double price){
        this.name = name;
        this.price = price;
    }
    
    public void setName(String name){
        
    }
    
    public String getName(){
        return this.name;
    }
    
    public void setPrice(double price){
        
    }
    
    public double getPrice(){
        return this.price;
    }
    
    public String toString(){
        return 
    }
    
}
