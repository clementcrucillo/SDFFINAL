package notificationsystem;

public class Notification {
    
}
