/*
Programmer: Ciara Mae Padillo
Purpose: Hands-on Activity on Control 
Date: 04.09.25
*/

package shoppingcartsystem;

public class Cart {
    private Item[] items;
    private int itemCount;
    private double totalAmount;
    
    public Cart(int size){
        items = new Item[size];
        itemCount = 0;
        totalAmount = 0.0;
    }
    
    public void setItems(Item[] items){
        this.items = items;
    }
    
    public Item[] getItems(){
        return items;
    }
    
    public void setItemCount(int itemCount){
        this.itemCount = itemCount;
    }
    
    public int getItemCount(){
        return itemCount;
    }
    
    public void setTotalAmount(double totalAmount){
        this.totalAmount = totalAmount;
    }
    
    public double getTotalAmount(){
        return totalAmount;
    }
    
    public void addItem(Item item){
        if(itemCount < items.length){
            items[itemCount] = item;
            itemCount++;
        }
    }
    
    public double computeSubtotal(){
        double subtotal = 0.0;
        for(int i = 0; i < itemCount; i++){
            subtotal += items[i].getsubtotal();
        }
        return subtotal;
    }
    
    public double applyDiscount(double subtotal){
        if (subtotal >= 500){
            return subtotal * 0.20;
        }
        else if(subtotal >= 200 && subtotal <500){
            return subtotal * 0.10;
        }
        else{
            return 0.0;
        }
    }
    
    public void displayCartSummary(){
        System.out.println("\nShopping Cart Summary");
        System.out.println("Item\t\Quantity\t\Price\t\Subtotal");
    }
}
