/*
Programmer: Ciara Mae Padillo
Purpose: Hands-on Activity on Control 
Date: 04.09.25
*/

import java.util.Scanner;

public class ShoppingCartSystem {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Enter number of items: ");
    }
    
}
