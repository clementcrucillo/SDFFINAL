package simplebankaccount;
import java.util.Scanner;

public class SimpleBankAccount{
    public static void (String[] args){
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Enter your name: ");
        String name = sc.nextLine();
        System.out.println("Enter your userId: ");
    }
}
