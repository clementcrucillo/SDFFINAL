package simplebankaccount;

public class BankAccount {
    private String userName;
    private String userId;
    private Double balance;
    
    public BankAccount(String userName, String userId, Double balance){
        this.userName = userName;
        this.userId = userId;
        this.balance = Math.max(0, balance);
    }
    
    public void setUserName(String name){
        this.userName = name;
    }
    
    public String getUserName(){
        return userName;
    }
    
    public void setUserId(String id){
        this.userId = id;
    }
    
    public String getUserId(){
        return userId;
    }
    
    public void deposit(double amount){
        if (amount > 0){
            balance += amount;
            System.out.println("Deposited: " + amount);
        }
        else{
            System.out.println("Invalid deposit amount!");
        }
    }
    
    public void withdraw(double amount){
        if(amount <= 0){
            System.out.println("Invalid withdrawal amount!");
        }
        else if(amount > balance){
            System.out.println("Insufficient funds! Withdraw failed.");
        }
        else{
            balance -= amount;
            System.out.println("Withdrew: " + amount);
        }
    }
    
    public void checkBalance(){
        System.out.println("Current balance: " + balance);
    }
            
}
