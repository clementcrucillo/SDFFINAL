package babarakalon;

/**
 *
 * @author bscs_2A - Allana Mae B. Estaquio
 */
public class Babarakalon {

    
    public static void main(String[] args) {
        
    }
    
}
