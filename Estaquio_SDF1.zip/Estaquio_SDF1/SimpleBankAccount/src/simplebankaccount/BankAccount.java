package simplebankaccount;

public class BankAccount {
    
    public static void main(String[] args){
        
    }
}
