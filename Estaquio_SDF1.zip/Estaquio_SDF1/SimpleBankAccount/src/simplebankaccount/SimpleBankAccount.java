package simplebankaccount;
/**
 *
 * @author bscs_2A - Allana Mae B. Estaquio
 */
public class SimpleBankAccount {
    private String userName;
    private String userId;
    private double balance;
    
    public SimpleBankAccount(String userName, String userId, Double balance){
        this.userName = userName;
        this.userId = userId;
        this.balance = balance;
    }
    
    public void setUserName(String userName){
        this.userName = userName;
    }
    
    public String getUserName(){
        return userName;
    }
    
    public void setUserId(String userId){
        this.userId = userId;
    }
    
    public String getUserId(){
        return userId;
    }
    
    public void deposit(double amount){
        if(amount > 0){
            balance += amount;
            System.out.println("Deposited: " + amount);
        }
        else{
            System.out.println("Invalid Amount");
        }
        }
    
    public void withdraw(double amount){
        if(amount > 0 && amount <= balance){
            balance -= amount;
            System.out.println("Withdrawal Amount: " + amount);
        }
        else{
            System.out.println("Invalid Amount");
        }
        }
    public void checkBalance(){
        System.out.println("Current Balance: " + balance);
    }
      
}
