package shoppingcartsystem;
import java.util.Scanner;
/**
 * Programmer: Allana Mae B. Estaquio
 * Purpose: Hands-on Activity on Control Structures and Encapsulation
 * Date: 04.09.2025
 */
public class ShoppingCartSystem {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        int num;
                
        System.out.println("Enter number of items: ");
        num = scanner.nextInt();
        
        Cart cart = new Cart(num);
        
        for (int i = 0; i = num; i++){
            scanner.nextLine();
            System.out.println("Enter item name: ");
            String name = scanner.nextLine();
            
            System.out.println("Enter price: ");
            double Price = scanner.nextDouble();
            
            System.out.println("Enter quantity: ");
            int Quantity = scanner.nextInt();
            
            Item item = new Item(name, Price, Quantity);
            cart.addItem(item);
            
        }
    }
    
}
