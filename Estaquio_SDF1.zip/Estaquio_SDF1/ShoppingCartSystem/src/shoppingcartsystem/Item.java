package shoppingcartsystem;
import java.util.Scanner;
/**
 * Programmer: Allana Mae B. Estaquio
 * Purpose: Hands-on Activity on Control Structures and Encapsulation
 * Date: 04.09.2025
 */
public class Item {
    private String itemName;
    private double price;
    private int quantity;
    

    public void setItemName(String itemName){
        this.itemName = itemName;
    }
    
    public String getItemName(){
        return this.itemName;
    }
    
    public void setPrice(double price){
        this.price = price;
    }
    
    public double getPrice(){
        return this.price;
    }
    
    public void setQuantity(int quantity){
        this.quantity = quantity;
    }
    
    public int getQuantity(){
        return this.quantity;
    }
    
    public double getTotalPrice(){
        return this.price * this.quantity;
    }
}

