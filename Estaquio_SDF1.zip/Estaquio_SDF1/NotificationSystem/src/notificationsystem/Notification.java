
package notificationsystem;

public class Notification {
    private String recipient;
    private String message;
    
    public Notification(String recipient, String message){
        this.recipient = recipient;
        this.message = message;
        
        public void send(){
            System.out.println("Sending a generic notification to " + recipient + ": " + message);
        }
        
        public void displayStatus(){
            System.out.println("Preparing notification for " + recipient);
        }
    }
}
