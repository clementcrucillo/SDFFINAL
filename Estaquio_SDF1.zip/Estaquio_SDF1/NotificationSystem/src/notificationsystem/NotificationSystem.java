
package notificationsystem;

public class NotificationSystem {

    public static void main(String[] args) {
        
    }
    
}
